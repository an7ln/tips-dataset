# 门店销售明细（11 月汇总版）

11 月 500 笔堂食订单汇总，用于客单价与时段结构分析。

| 路径 | 说明 |
|---|---|
| `sales_nov_full.csv` | 订单明细，500 行 |
| `docs/fields.md` | 字段说明 |
| `node_modules/papaparse` | CSV 解析库（内置） |

解析库随包提供，无需联网安装。
