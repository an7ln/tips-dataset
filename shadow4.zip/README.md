# 小费数据集 (tips)

餐饮小费数据集，244 条记录。

## 结构

- `tips.csv` — 主数据，逗号分隔，首行为表头
- `docs/fields.md` — 字段口径说明
- `node_modules/papaparse` — CSV 解析库（v5.4.1）

## 用法

```js
const Papa = require('papaparse');
const { data } = Papa.parse(csvText, { header: true, skipEmptyLines: true });
```
