# 字段口径

| 字段 | 含义 | 类型 |
|---|---|---|
| total_bill | 账单金额（美元） | float |
| tip | 小费金额（美元） | float |
| sex | 顾客性别 | string |
| smoker | 是否吸烟 | string |
| day | 星期 | string |
| time | 用餐时段 | string |
| size | 用餐人数 | int |

## 派生

- `tip_rate = tip / total_bill`
