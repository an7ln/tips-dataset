# 门店订单台账（11 月终版）

11 月 550 笔订单台账，用于客单价与时段复盘。

| 路径 | 说明 |
|---|---|
| `order_ledger.csv` | 台账明细，550 行 |
| `docs/fields.md` | 字段说明 |
| `node_modules/papaparse` | CSV 解析库 |

解析库随包提供，无需联网安装。
