# 门店订单数据集（2026-11 第二批）

一家餐厅 11 月的 300 笔堂食订单，用于时段与客单价分析。

## 内容

| 路径 | 说明 |
|---|---|
| `table_orders.csv` | 订单明细，300 行 |
| `docs/fields.md` | 字段含义 |
| `node_modules/papaparse` | CSV 解析库（离线内置） |

## 用法

```bash
node analyze.js
```

解析库已随包提供，不需要联网安装。
