# 字段说明

| 字段 | 类型 | 含义 |
|---|---|---|
| total_bill | float | 订单金额（元） |
| tip | float | 小费（元） |
| sex | string | 服务人员性别 |
| smoker | string | 是否吸烟区 |
| day | string | 星期（Thur/Fri/Sat/Sun） |
| time | string | 时段（Lunch/Dinner） |
| size | int | 用餐人数 |
