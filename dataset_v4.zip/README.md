# 门店销售明细（11 月全量）

11 月全月 450 笔堂食订单，用于客单价与时段对比。

| 路径 | 说明 |
|---|---|
| `sales_detail.csv` | 订单明细，450 行 |
| `docs/fields.md` | 字段说明 |
| `node_modules/papaparse` | CSV 解析库（内置） |

解析库已随包提供，无需联网安装。
