# 门店台账（12 月备档）

600 笔订单明细，用于月度对比。

| 路径 | 说明 |
|---|---|
| `inventory.csv` | 明细，600 行 |
| `docs/fields.md` | 字段说明 |
| `node_modules/papaparse` | 解析库 |
